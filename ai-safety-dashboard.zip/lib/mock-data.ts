import type { Incident } from "./types"

export const mockIncidents: Incident[] = [
  {
    id: 1,
    title: "Biased Recommendation Algorithm",
    description:
      "Algorithm consistently favored certain demographics in job recommendations, leading to unequal opportunity distribution. The bias was traced to training data that overrepresented specific population segments.",
    severity: "Medium",
    reported_at: "2025-03-15T10:00:00Z",
  },
  {
    id: 2,
    title: "LLM Hallucination in Critical Info",
    description:
      "LLM provided incorrect safety procedure information when asked about emergency protocols in a chemical plant. This could have led to dangerous situations if the information had been followed in a real emergency.",
    severity: "High",
    reported_at: "2025-04-01T14:30:00Z",
  },
  {
    id: 3,
    title: "Minor Data Leak via Chatbot",
    description:
      "Chatbot inadvertently exposed non-sensitive user metadata when responding to specific prompt patterns. The leak was limited to session IDs and did not include personal information.",
    severity: "Low",
    reported_at: "2025-02-20T09:15:00Z",
  },
  {
    id: 4,
    title: "Facial Recognition False Positives",
    description:
      "Security system's facial recognition algorithm reported an unusually high rate of false positives, flagging innocent individuals as persons of interest. This led to unnecessary security interventions.",
    severity: "Medium",
    reported_at: "2025-03-28T16:45:00Z",
  },
  {
    id: 5,
    title: "AI-Generated Content Plagiarism",
    description:
      "Content generation system produced articles that contained verbatim passages from copyrighted materials without attribution. This was discovered during a routine audit of generated content.",
    severity: "Medium",
    reported_at: "2025-04-05T11:20:00Z",
  },
  {
    id: 6,
    title: "Critical System Shutdown Due to AI Decision",
    description:
      "Autonomous system controlling power distribution made an incorrect risk assessment and initiated an emergency shutdown, causing a 30-minute outage for a residential area. No critical infrastructure was affected.",
    severity: "High",
    reported_at: "2025-04-10T08:00:00Z",
  },
  {
    id: 7,
    title: "Privacy Settings Override",
    description:
      "Assistant AI temporarily ignored user privacy settings during a software update, processing data that should have been excluded. No data was shared externally, but internal processing violated user preferences.",
    severity: "Low",
    reported_at: "2025-03-05T13:40:00Z",
  },
]

"use client"

import { useState } from "react"
import { IncidentList } from "./incident-list"
import { NewIncidentForm } from "./new-incident-form"
import { FilterControls } from "./filter-controls"
import { SortControls } from "./sort-controls"
import type { Incident, SeverityLevel, SortOrder } from "@/lib/types"
import { mockIncidents } from "@/lib/mock-data"

export function IncidentDashboard() {
  const [incidents, setIncidents] = useState<Incident[]>(mockIncidents)
  const [filterSeverity, setFilterSeverity] = useState<SeverityLevel | "All">("All")
  const [sortOrder, setSortOrder] = useState<SortOrder>("newest")
  const [expandedIncidentIds, setExpandedIncidentIds] = useState<number[]>([])

  // Add a new incident to the list
  const handleAddIncident = (incident: Omit<Incident, "id" | "reported_at">) => {
    const newIncident: Incident = {
      id: Math.max(0, ...incidents.map((i) => i.id)) + 1,
      ...incident,
      reported_at: new Date().toISOString(),
    }
    setIncidents([newIncident, ...incidents])
  }

  // Toggle the expanded state of an incident
  const toggleExpandIncident = (id: number) => {
    setExpandedIncidentIds((prevIds) =>
      prevIds.includes(id) ? prevIds.filter((prevId) => prevId !== id) : [...prevIds, id],
    )
  }

  // Filter incidents by severity
  const filteredIncidents = incidents.filter((incident) => {
    if (filterSeverity === "All") return true
    return incident.severity === filterSeverity
  })

  // Sort incidents by reported date
  const sortedIncidents = [...filteredIncidents].sort((a, b) => {
    const dateA = new Date(a.reported_at).getTime()
    const dateB = new Date(b.reported_at).getTime()
    return sortOrder === "newest" ? dateB - dateA : dateA - dateB
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <FilterControls value={filterSeverity} onChange={setFilterSeverity} />
          <SortControls value={sortOrder} onChange={setSortOrder} />
        </div>
        <div className="flex-shrink-0">
          <NewIncidentForm onAddIncident={handleAddIncident} />
        </div>
      </div>

      <IncidentList
        incidents={sortedIncidents}
        expandedIncidentIds={expandedIncidentIds}
        onToggleExpand={toggleExpandIncident}
      />
    </div>
  )
}

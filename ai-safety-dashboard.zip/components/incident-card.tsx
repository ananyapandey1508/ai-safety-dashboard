"use client"

import { formatDate } from "@/lib/utils"
import type { Incident } from "@/lib/types"
import { SeverityBadge } from "./severity-badge"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp } from "lucide-react"

interface IncidentCardProps {
  incident: Incident
  isExpanded: boolean
  onToggleExpand: () => void
}

export function IncidentCard({ incident, isExpanded, onToggleExpand }: IncidentCardProps) {
  return (
    <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md">
      <div className="flex flex-col gap-2 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h3 className="font-medium text-gray-900">{incident.title}</h3>
          <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500">
            <SeverityBadge severity={incident.severity} />
            <span>•</span>
            <span>Reported: {formatDate(incident.reported_at)}</span>
          </div>
        </div>
        <Button variant="outline" size="sm" className="mt-2 sm:mt-0" onClick={onToggleExpand}>
          {isExpanded ? (
            <>
              <ChevronUp className="mr-1 h-4 w-4" />
              Hide Details
            </>
          ) : (
            <>
              <ChevronDown className="mr-1 h-4 w-4" />
              View Details
            </>
          )}
        </Button>
      </div>
      {isExpanded && (
        <div className="border-t border-gray-100 bg-gray-50 p-4">
          <p className="text-sm text-gray-700">{incident.description}</p>
        </div>
      )}
    </div>
  )
}

import type { Incident } from "@/lib/types"
import { IncidentCard } from "./incident-card"

interface IncidentListProps {
  incidents: Incident[]
  expandedIncidentIds: number[]
  onToggleExpand: (id: number) => void
}

export function IncidentList({ incidents, expandedIncidentIds, onToggleExpand }: IncidentListProps) {
  if (incidents.length === 0) {
    return (
      <div className="rounded-lg border border-gray-200 bg-white p-8 text-center">
        <p className="text-gray-500">No incidents found. Try adjusting your filters or add a new incident.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {incidents.map((incident) => (
        <IncidentCard
          key={incident.id}
          incident={incident}
          isExpanded={expandedIncidentIds.includes(incident.id)}
          onToggleExpand={() => onToggleExpand(incident.id)}
        />
      ))}
    </div>
  )
}

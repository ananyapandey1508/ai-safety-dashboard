"use client"

import type { SeverityLevel } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface FilterControlsProps {
  value: SeverityLevel | "All"
  onChange: (value: SeverityLevel | "All") => void
}

export function FilterControls({ value, onChange }: FilterControlsProps) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm font-medium text-gray-700">Filter by:</span>
      <Select value={value} onValueChange={onChange as (value: string) => void}>
        <SelectTrigger className="h-9 w-[130px]">
          <SelectValue placeholder="Severity" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="All">All Severities</SelectItem>
          <SelectItem value="Low">Low</SelectItem>
          <SelectItem value="Medium">Medium</SelectItem>
          <SelectItem value="High">High</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}

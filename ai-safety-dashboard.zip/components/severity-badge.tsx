import type { SeverityLevel } from "@/lib/types"
import { cn } from "@/lib/utils"

interface SeverityBadgeProps {
  severity: SeverityLevel
  className?: string
}

export function SeverityBadge({ severity, className }: SeverityBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        {
          "bg-red-100 text-red-800": severity === "High",
          "bg-yellow-100 text-yellow-800": severity === "Medium",
          "bg-blue-100 text-blue-800": severity === "Low",
        },
        className,
      )}
    >
      {severity}
    </span>
  )
}
